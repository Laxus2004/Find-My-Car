package com.example.findmycar

import android.Manifest
import android.Manifest.permission.ACCESS_FINE_LOCATION
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.location.Location
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.DrawableRes
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.app.ActivityCompat.shouldShowRequestPermissionRationale
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.DrawableCompat

import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.MarkerOptions
import com.example.findmycar.databinding.ActivityMapsBinding
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.model.BitmapDescriptor
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.Marker

class MapsActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap
    private var marker: Marker? = null // Marker for the parked car

    private lateinit var binding: ActivityMapsBinding
    private lateinit var requestPermissionLauncher: ActivityResultLauncher<String>

    private val fusedLocationProviderClient by lazy {
        LocationServices
            .getFusedLocationProviderClient(this)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMapsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        requestPermissionLauncher =
            registerForActivityResult(ActivityResultContracts.RequestPermission()) {
                    isGranted ->
                if (isGranted) { getLastLocation() }
                else {
                    showPermissionRationale {
                        requestPermissionLauncher
                            .launch(ACCESS_FINE_LOCATION)
                    }
                }
            }

        // Set up the click listener for the "I'm parked here" button
        binding.parkedButton.setOnClickListener {
            // This will get the current location and use it to move/save the car marker
            parkCarAtCurrentLocation()
        }
    }

    /**
     * Manipulates the map once available.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap.apply {
            // Allows the user to tap the map to place the car marker
            setOnMapClickListener { latLng ->
                addOrMoveSelectedPositionMarker(latLng)
            }
        }

        // 1. Check for and restore the saved car location first
        restoreLocation()?.let { savedLatLng ->
            marker = addMarkerAtLocation(
                savedLatLng,
                "I'm parked here",
                getBitmapDescriptorFromVector(R.drawable.car_icon)
            )
            updateMapLocation(savedLatLng)
        }

        // 2. Request user location (will also place the 'You' marker)
        when {
            hasLocationPermission() -> getLastLocation()
            shouldShowRequestPermissionRationale(this,
                ACCESS_FINE_LOCATION) -> {
                showPermissionRationale {
                    requestPermissionLauncher
                        .launch(ACCESS_FINE_LOCATION)
                }
            }
            else -> requestPermissionLauncher
                .launch(ACCESS_FINE_LOCATION)
        }
    }

    private fun parkCarAtCurrentLocation() {
        if (!hasLocationPermission()) {
            requestPermissionLauncher.launch(ACCESS_FINE_LOCATION)
            return
        }

        // Get the current user location and move the car marker there
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return
        }
        fusedLocationProviderClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                location?.let {
                    val currentLatLng = LatLng(it.latitude, it.longitude)
                    // Moves the car marker and saves the location
                    addOrMoveSelectedPositionMarker(currentLatLng)
                    // Move the map camera to the new car location
                    updateMapLocation(currentLatLng)
                }
            }
    }

    private fun getLastLocation() {
        // This check is required because the compiler can't guarantee permission after the check in onMapReady
        if (ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) != PackageManager.PERMISSION_GRANTED
        ) {
            // Permission is needed, but this function is called only when permission is granted.
            // This return is mostly to satisfy the static code analysis.
            return
        }

        fusedLocationProviderClient.lastLocation
            .addOnSuccessListener { location: Location? ->
                location?.let {
                    val userLocation = LatLng(
                        location.latitude, location.longitude)

                    // Only update the map location if no car location was loaded from SharedPreferences
                    if (marker == null) {
                        updateMapLocation(userLocation)
                    }

                    // Always add the 'You' marker for the current location
                    addMarkerAtLocation(userLocation, "You")
                }
            }
    }


    private fun showPermissionRationale(positiveAction: ()
    -> Unit) {
        AlertDialog.Builder(this)
            .setTitle("Location permission")
            .setMessage("This app will not work without knowing your current location")
            .setPositiveButton(android.R.string.ok) { _, _ ->
                positiveAction() }
            .setNegativeButton(android.R.string.cancel) { dialog, _ -> dialog.dismiss() }
            .create().show()
    }

    private fun hasLocationPermission() =
        ContextCompat.checkSelfPermission(
            this, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    private fun updateMapLocation(location: LatLng) {
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(
            location, 15f)) // Using a closer zoom level (e.g., 15f) for better visibility
    }

    private fun addMarkerAtLocation(
        location: LatLng, title: String,
        markerIcon: BitmapDescriptor? = null
    ) = mMap.addMarker(
        MarkerOptions().title(title).position(location)
            .apply { markerIcon?.let { icon(markerIcon) } }
    )

    private fun getBitmapDescriptorFromVector(@DrawableRes vectorDrawableResourceId: Int): BitmapDescriptor? {
        val bitmap = ContextCompat.getDrawable(this,
            vectorDrawableResourceId)?.let { vectorDrawable ->
            vectorDrawable.setBounds(0, 0,
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight)
            val drawableWithTint = DrawableCompat
                .wrap(vectorDrawable)
            // You might want to change the tint color for the car icon
            DrawableCompat.setTint(drawableWithTint, Color.RED)
            val bitmap = Bitmap.createBitmap(
                vectorDrawable.intrinsicWidth,
                vectorDrawable.intrinsicHeight,
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bitmap)
            drawableWithTint.draw(canvas)
            bitmap
        }
        return bitmap?.let { BitmapDescriptorFactory.fromBitmap(it) }
            .also { bitmap?.recycle() }
    }

    private fun addOrMoveSelectedPositionMarker(latLng:
                                                LatLng) {
        if (marker == null) {
            // First time placing the marker (car icon)
            marker = addMarkerAtLocation(latLng,
                "I'm parked here", getBitmapDescriptorFromVector(
                    R.drawable.car_icon)
            )
        } else {
            // Move the existing marker
            marker?.apply { position = latLng }
        }
        // Save the location to SharedPreferences every time it's updated
        saveLocation(latLng)
    }

    // ⭐ BONUS: Saves the car's location
    private fun saveLocation(latLng: LatLng) =
        getPreferences(MODE_PRIVATE)?.edit()?.apply {
            putString("latitude", latLng.latitude.toString())
            putString("longitude", latLng.longitude.toString())
            apply()
        }

    // ⭐ BONUS: Restores the car's location
    private fun restoreLocation(): LatLng? {
        val sharedPreferences = getPreferences(MODE_PRIVATE) ?: return null

        val latitude = sharedPreferences.getString("latitude", null)?.toDoubleOrNull() ?: return null
        val longitude = sharedPreferences.getString("longitude", null)?.toDoubleOrNull() ?: return null

        return LatLng(latitude, longitude)
    }
}